
  # Dark Themed Mobile UI

  This is a code bundle for Dark Themed Mobile UI. The original project is available at https://www.figma.com/design/a91rjRbBwZukCyfmH2JUtH/Dark-Themed-Mobile-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  